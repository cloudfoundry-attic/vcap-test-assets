#!/bin/sh
echo -n "I'm a simple script"
while true
do
   sleep 1
done
